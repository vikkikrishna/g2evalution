import { Component, OnInit,Inject } from '@angular/core';
import { RouterLinkActive } from '@angular/router';

import * as $ from 'jquery';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() {
    // @Inject(RouterLinkActive) private active: RouterLinkActive
   }
 
  ngOnInit() {

  }

  ngAfterViewInit(){

    $("#toggle-btn").click(function() {
      $(".sf-menu").slideToggle("slow"); 
  });

  $('.toggle-subarrow').click(
      function() {
          $(this).parent().toggleClass("mob-drop");
  });
  

  }
//   status: boolean = true;
// clickEvent(){
//     this.status = !this.status;       
// }

}
